طريقة بناء الـ APK:
1) نزّل Android Studio (مجاني) من developer.android.com/studio
2) File > Open واختر مجلد CarScreen، وانتظر Gradle Sync يخلص (يحتاج إنترنت).
3) Build > Build Bundle(s) / APK(s) > Build APK(s)
4) الملف يطلع في: app/build/outputs/apk/debug/app-debug.apk
5) انقله للشاشة (فلاشة أو واي فاي) وثبّته. فعّل "التثبيت من مصادر غير معروفة" إذا طلب.

ملاحظة: الصفحة نفسها داخل app/src/main/assets/index.html

اتصال OBD:
1) ركّب قطعة ELM327 WiFi في السيارة وشغّل السيارة.
2) من إعدادات واي فاي الشاشة اتصل بشبكة القطعة (اسمها مثل OBDII أو WiFi_OBDII).
3) افتح التطبيق > Vehicle > Connect OBD (العنوان الافتراضي 192.168.0.10 والمنفذ 35000).
